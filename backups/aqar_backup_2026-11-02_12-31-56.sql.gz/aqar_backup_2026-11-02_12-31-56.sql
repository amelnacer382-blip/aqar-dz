--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2
-- Dumped by pg_dump version 17.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.visits DROP CONSTRAINT IF EXISTS visits_property_id_fkey;
ALTER TABLE IF EXISTS ONLY public.visits DROP CONSTRAINT IF EXISTS visits_client_id_fkey;
ALTER TABLE IF EXISTS ONLY public.visits DROP CONSTRAINT IF EXISTS visits_agency_id_fkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_agency_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS sales_property_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS sales_owner_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS sales_client_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS sales_agency_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rentals DROP CONSTRAINT IF EXISTS rentals_property_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rentals DROP CONSTRAINT IF EXISTS rentals_owner_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rentals DROP CONSTRAINT IF EXISTS rentals_client_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rentals DROP CONSTRAINT IF EXISTS rentals_agency_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rental_managements DROP CONSTRAINT IF EXISTS rental_managements_rental_id_fkey;
ALTER TABLE IF EXISTS ONLY public.property_images DROP CONSTRAINT IF EXISTS property_images_property_id_fkey;
ALTER TABLE IF EXISTS ONLY public.properties DROP CONSTRAINT IF EXISTS properties_owner_id_fkey;
ALTER TABLE IF EXISTS ONLY public.properties DROP CONSTRAINT IF EXISTS properties_agency_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_sale_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_rental_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_property_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_owner_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_client_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_agency_id_fkey;
ALTER TABLE IF EXISTS ONLY public.password_reset_tokens DROP CONSTRAINT IF EXISTS password_reset_tokens_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.owners DROP CONSTRAINT IF EXISTS owners_agency_id_fkey;
ALTER TABLE IF EXISTS ONLY public.leads DROP CONSTRAINT IF EXISTS leads_property_id_fkey;
ALTER TABLE IF EXISTS ONLY public.leads DROP CONSTRAINT IF EXISTS leads_agency_id_fkey;
ALTER TABLE IF EXISTS ONLY public.interactions DROP CONSTRAINT IF EXISTS interactions_owner_id_fkey;
ALTER TABLE IF EXISTS ONLY public.interactions DROP CONSTRAINT IF EXISTS interactions_client_id_fkey;
ALTER TABLE IF EXISTS ONLY public.interactions DROP CONSTRAINT IF EXISTS interactions_agency_id_fkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_agency_id_fkey;
ALTER TABLE IF EXISTS ONLY public.clients DROP CONSTRAINT IF EXISTS clients_agency_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_agency_id_fkey;
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS accounts_user_id_fkey;
DROP INDEX IF EXISTS public.visits_status_idx;
DROP INDEX IF EXISTS public.visits_property_id_idx;
DROP INDEX IF EXISTS public.visits_client_id_idx;
DROP INDEX IF EXISTS public.visits_agency_id_idx;
DROP INDEX IF EXISTS public.verificationtokens_token_key;
DROP INDEX IF EXISTS public.verificationtokens_identifier_token_key;
DROP INDEX IF EXISTS public.users_email_key;
DROP INDEX IF EXISTS public.sessions_session_token_key;
DROP INDEX IF EXISTS public.sales_status_idx;
DROP INDEX IF EXISTS public.sales_property_id_idx;
DROP INDEX IF EXISTS public.sales_client_id_idx;
DROP INDEX IF EXISTS public.sales_agency_id_idx;
DROP INDEX IF EXISTS public.rentals_status_idx;
DROP INDEX IF EXISTS public.rentals_property_id_idx;
DROP INDEX IF EXISTS public.rentals_client_id_idx;
DROP INDEX IF EXISTS public.rentals_agency_id_idx;
DROP INDEX IF EXISTS public.rental_managements_rental_id_month_year_key;
DROP INDEX IF EXISTS public.rental_managements_rental_id_idx;
DROP INDEX IF EXISTS public.rental_managements_reference_key;
DROP INDEX IF EXISTS public.property_images_property_id_idx;
DROP INDEX IF EXISTS public.properties_wilaya_idx;
DROP INDEX IF EXISTS public.properties_type_idx;
DROP INDEX IF EXISTS public.properties_status_idx;
DROP INDEX IF EXISTS public.properties_reference_key;
DROP INDEX IF EXISTS public.properties_operation_type_idx;
DROP INDEX IF EXISTS public.properties_deleted_at_idx;
DROP INDEX IF EXISTS public.properties_agency_id_idx;
DROP INDEX IF EXISTS public.payments_type_idx;
DROP INDEX IF EXISTS public.payments_status_idx;
DROP INDEX IF EXISTS public.payments_rental_id_idx;
DROP INDEX IF EXISTS public.payments_reference_key;
DROP INDEX IF EXISTS public.payments_property_id_idx;
DROP INDEX IF EXISTS public.payments_agency_id_idx;
DROP INDEX IF EXISTS public.password_reset_tokens_user_id_idx;
DROP INDEX IF EXISTS public.password_reset_tokens_token_hash_key;
DROP INDEX IF EXISTS public.password_reset_tokens_expires_at_idx;
DROP INDEX IF EXISTS public.owners_deleted_at_idx;
DROP INDEX IF EXISTS public.owners_agency_id_idx;
DROP INDEX IF EXISTS public.leads_status_idx;
DROP INDEX IF EXISTS public.leads_agency_id_idx;
DROP INDEX IF EXISTS public.interactions_owner_id_idx;
DROP INDEX IF EXISTS public.interactions_client_id_idx;
DROP INDEX IF EXISTS public.interactions_agency_id_idx;
DROP INDEX IF EXISTS public.documents_type_idx;
DROP INDEX IF EXISTS public.documents_agency_id_idx;
DROP INDEX IF EXISTS public.clients_status_idx;
DROP INDEX IF EXISTS public.clients_deleted_at_idx;
DROP INDEX IF EXISTS public.clients_agency_id_idx;
DROP INDEX IF EXISTS public.audit_logs_entity_entity_id_idx;
DROP INDEX IF EXISTS public.audit_logs_agency_id_created_at_idx;
DROP INDEX IF EXISTS public.agencies_slug_key;
DROP INDEX IF EXISTS public.agencies_email_key;
DROP INDEX IF EXISTS public.accounts_provider_provider_account_id_key;
ALTER TABLE IF EXISTS ONLY public.visits DROP CONSTRAINT IF EXISTS visits_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS sales_pkey;
ALTER TABLE IF EXISTS ONLY public.rentals DROP CONSTRAINT IF EXISTS rentals_pkey;
ALTER TABLE IF EXISTS ONLY public.rental_managements DROP CONSTRAINT IF EXISTS rental_managements_pkey;
ALTER TABLE IF EXISTS ONLY public.property_images DROP CONSTRAINT IF EXISTS property_images_pkey;
ALTER TABLE IF EXISTS ONLY public.properties DROP CONSTRAINT IF EXISTS properties_pkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_pkey;
ALTER TABLE IF EXISTS ONLY public.password_reset_tokens DROP CONSTRAINT IF EXISTS password_reset_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.owners DROP CONSTRAINT IF EXISTS owners_pkey;
ALTER TABLE IF EXISTS ONLY public.leads DROP CONSTRAINT IF EXISTS leads_pkey;
ALTER TABLE IF EXISTS ONLY public.interactions DROP CONSTRAINT IF EXISTS interactions_pkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_pkey;
ALTER TABLE IF EXISTS ONLY public.clients DROP CONSTRAINT IF EXISTS clients_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.agencies DROP CONSTRAINT IF EXISTS agencies_pkey;
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS accounts_pkey;
DROP TABLE IF EXISTS public.visits;
DROP TABLE IF EXISTS public.verificationtokens;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.sessions;
DROP TABLE IF EXISTS public.sales;
DROP TABLE IF EXISTS public.rentals;
DROP TABLE IF EXISTS public.rental_managements;
DROP TABLE IF EXISTS public.property_images;
DROP TABLE IF EXISTS public.properties;
DROP TABLE IF EXISTS public.payments;
DROP TABLE IF EXISTS public.password_reset_tokens;
DROP TABLE IF EXISTS public.owners;
DROP TABLE IF EXISTS public.leads;
DROP TABLE IF EXISTS public.interactions;
DROP TABLE IF EXISTS public.documents;
DROP TABLE IF EXISTS public.clients;
DROP TABLE IF EXISTS public.audit_logs;
DROP TABLE IF EXISTS public.agencies;
DROP TABLE IF EXISTS public.accounts;
DROP TYPE IF EXISTS public."VisitStatus";
DROP TYPE IF EXISTS public."UserRole";
DROP TYPE IF EXISTS public."SaleStatus";
DROP TYPE IF EXISTS public."RentalStatus";
DROP TYPE IF EXISTS public."PropertyType";
DROP TYPE IF EXISTS public."PropertyStatus";
DROP TYPE IF EXISTS public."PropertyCategory";
DROP TYPE IF EXISTS public."PaymentType";
DROP TYPE IF EXISTS public."PaymentStatus";
DROP TYPE IF EXISTS public."PaymentMethod";
DROP TYPE IF EXISTS public."OperationType";
DROP TYPE IF EXISTS public."LeadStatus";
DROP TYPE IF EXISTS public."InterestLevel";
DROP TYPE IF EXISTS public."InteractionType";
DROP TYPE IF EXISTS public."DocumentType";
DROP TYPE IF EXISTS public."ClientType";
DROP TYPE IF EXISTS public."ClientStatus";
DROP TYPE IF EXISTS public."AgencyStatus";
DROP TYPE IF EXISTS public."AgencyPlan";
--
-- Name: AgencyPlan; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."AgencyPlan" AS ENUM (
    'starter',
    'pro',
    'enterprise'
);


ALTER TYPE public."AgencyPlan" OWNER TO aqar_user;

--
-- Name: AgencyStatus; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."AgencyStatus" AS ENUM (
    'pending',
    'active',
    'suspended'
);


ALTER TYPE public."AgencyStatus" OWNER TO aqar_user;

--
-- Name: ClientStatus; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."ClientStatus" AS ENUM (
    'nouveau',
    'interesse',
    'visite_prevue',
    'client_chaud',
    'conclu',
    'perdu'
);


ALTER TYPE public."ClientStatus" OWNER TO aqar_user;

--
-- Name: ClientType; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."ClientType" AS ENUM (
    'acheteur',
    'locataire',
    'investisseur',
    'interesse'
);


ALTER TYPE public."ClientType" OWNER TO aqar_user;

--
-- Name: DocumentType; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."DocumentType" AS ENUM (
    'contrat_vente',
    'contrat_location',
    'recu_paiement',
    'fiche_bien',
    'rapport_proprietaire',
    'piece_identite',
    'acte_propriete',
    'image_bien',
    'plan_bien'
);


ALTER TYPE public."DocumentType" OWNER TO aqar_user;

--
-- Name: InteractionType; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."InteractionType" AS ENUM (
    'appel',
    'email',
    'sms',
    'rendez_vous',
    'visite',
    'note',
    'relance'
);


ALTER TYPE public."InteractionType" OWNER TO aqar_user;

--
-- Name: InterestLevel; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."InterestLevel" AS ENUM (
    'tres_interesse',
    'interesse',
    'mitige',
    'pas_interesse'
);


ALTER TYPE public."InterestLevel" OWNER TO aqar_user;

--
-- Name: LeadStatus; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."LeadStatus" AS ENUM (
    'nouveau',
    'traite',
    'archive'
);


ALTER TYPE public."LeadStatus" OWNER TO aqar_user;

--
-- Name: OperationType; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."OperationType" AS ENUM (
    'vente',
    'location',
    'gestion_locative'
);


ALTER TYPE public."OperationType" OWNER TO aqar_user;

--
-- Name: PaymentMethod; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."PaymentMethod" AS ENUM (
    'cash',
    'virement',
    'ccp',
    'autre'
);


ALTER TYPE public."PaymentMethod" OWNER TO aqar_user;

--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'paye',
    'partiel',
    'impaye'
);


ALTER TYPE public."PaymentStatus" OWNER TO aqar_user;

--
-- Name: PaymentType; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."PaymentType" AS ENUM (
    'loyer',
    'caution',
    'commission_agence',
    'frais_dossier',
    'avance',
    'paiement_proprietaire',
    'abonnement_saas'
);


ALTER TYPE public."PaymentType" OWNER TO aqar_user;

--
-- Name: PropertyCategory; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."PropertyCategory" AS ENUM (
    'residentiel',
    'commercial',
    'professionnel',
    'industriel',
    'touristique',
    'agricole'
);


ALTER TYPE public."PropertyCategory" OWNER TO aqar_user;

--
-- Name: PropertyStatus; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."PropertyStatus" AS ENUM (
    'disponible',
    'vendu',
    'loue',
    'reserve',
    'archive'
);


ALTER TYPE public."PropertyStatus" OWNER TO aqar_user;

--
-- Name: PropertyType; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."PropertyType" AS ENUM (
    'appartement',
    'villa',
    'studio',
    'duplex',
    'maison',
    'residence',
    'terrain_constructible',
    'local_commercial',
    'boutique',
    'showroom',
    'restaurant',
    'cafe',
    'magasin',
    'bureau',
    'cabinet_medical',
    'espace_coworking',
    'immeuble_professionnel',
    'plateau_bureaux',
    'hangar',
    'entrepot',
    'usine',
    'depot',
    'terrain_industriel',
    'bungalow',
    'villa_vacances',
    'residence_estivale',
    'appartement_saisonnier',
    'chalet',
    'maison_hotes',
    'terrain_agricole',
    'ferme',
    'exploitation_agricole',
    'serre_agricole',
    'domaine_agricole'
);


ALTER TYPE public."PropertyType" OWNER TO aqar_user;

--
-- Name: RentalStatus; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."RentalStatus" AS ENUM (
    'active',
    'terminee',
    'annulee'
);


ALTER TYPE public."RentalStatus" OWNER TO aqar_user;

--
-- Name: SaleStatus; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."SaleStatus" AS ENUM (
    'negociation',
    'compromis',
    'vendu',
    'annule'
);


ALTER TYPE public."SaleStatus" OWNER TO aqar_user;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."UserRole" AS ENUM (
    'super_admin',
    'agency_admin',
    'agent'
);


ALTER TYPE public."UserRole" OWNER TO aqar_user;

--
-- Name: VisitStatus; Type: TYPE; Schema: public; Owner: aqar_user
--

CREATE TYPE public."VisitStatus" AS ENUM (
    'prevue',
    'effectuee',
    'annulee',
    'reportee'
);


ALTER TYPE public."VisitStatus" OWNER TO aqar_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.accounts (
    id text NOT NULL,
    user_id text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    provider_account_id text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


ALTER TABLE public.accounts OWNER TO aqar_user;

--
-- Name: agencies; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.agencies (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    address text,
    wilaya text,
    commune text,
    logo text,
    status public."AgencyStatus" DEFAULT 'pending'::public."AgencyStatus" NOT NULL,
    plan public."AgencyPlan" DEFAULT 'starter'::public."AgencyPlan" NOT NULL,
    requested_plan public."AgencyPlan",
    subscription_ends_at timestamp(3) without time zone,
    slug text,
    description text,
    showcase_enabled boolean DEFAULT true NOT NULL,
    primary_color text DEFAULT '#0f172a'::text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.agencies OWNER TO aqar_user;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    agency_id text,
    user_id text,
    user_name text,
    action text NOT NULL,
    entity text NOT NULL,
    entity_id text,
    summary text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO aqar_user;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.clients (
    id text NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    phone text,
    email text,
    budget numeric(15,2),
    property_type public."PropertyType",
    wilaya text,
    category public."PropertyCategory",
    type public."ClientType" DEFAULT 'interesse'::public."ClientType" NOT NULL,
    status public."ClientStatus" DEFAULT 'nouveau'::public."ClientStatus" NOT NULL,
    notes text,
    agency_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    deleted_at timestamp(3) without time zone
);


ALTER TABLE public.clients OWNER TO aqar_user;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.documents (
    id text NOT NULL,
    name text NOT NULL,
    type public."DocumentType" NOT NULL,
    url text NOT NULL,
    size integer,
    mime_type text,
    agency_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.documents OWNER TO aqar_user;

--
-- Name: interactions; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.interactions (
    id text NOT NULL,
    type public."InteractionType" NOT NULL,
    subject text NOT NULL,
    content text,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    author_id text,
    client_id text,
    owner_id text,
    agency_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.interactions OWNER TO aqar_user;

--
-- Name: leads; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.leads (
    id text NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    phone text,
    email text,
    message text NOT NULL,
    status public."LeadStatus" DEFAULT 'nouveau'::public."LeadStatus" NOT NULL,
    property_id text,
    agency_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.leads OWNER TO aqar_user;

--
-- Name: owners; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.owners (
    id text NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    phone text,
    email text,
    address text,
    id_card_number text,
    notes text,
    agency_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    deleted_at timestamp(3) without time zone
);


ALTER TABLE public.owners OWNER TO aqar_user;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.password_reset_tokens (
    id text NOT NULL,
    token_hash text NOT NULL,
    user_id text NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    used_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.password_reset_tokens OWNER TO aqar_user;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.payments (
    id text NOT NULL,
    reference text NOT NULL,
    amount numeric(15,2) NOT NULL,
    type public."PaymentType" NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    method public."PaymentMethod" DEFAULT 'cash'::public."PaymentMethod" NOT NULL,
    status public."PaymentStatus" DEFAULT 'paye'::public."PaymentStatus" NOT NULL,
    receipt text,
    notes text,
    property_id text,
    client_id text,
    owner_id text,
    rental_id text,
    sale_id text,
    agency_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.payments OWNER TO aqar_user;

--
-- Name: properties; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.properties (
    id text NOT NULL,
    reference text NOT NULL,
    title text NOT NULL,
    category public."PropertyCategory" NOT NULL,
    type public."PropertyType" NOT NULL,
    status public."PropertyStatus" DEFAULT 'disponible'::public."PropertyStatus" NOT NULL,
    operation_type public."OperationType" NOT NULL,
    sale_price numeric(15,2),
    rent_price numeric(15,2),
    currency text DEFAULT 'DZD'::text NOT NULL,
    wilaya text NOT NULL,
    commune text NOT NULL,
    quartier text,
    address text,
    surface double precision,
    rooms integer,
    bedrooms integer,
    bathrooms integer,
    floor integer,
    total_floors integer,
    has_garage boolean DEFAULT false NOT NULL,
    has_garden boolean DEFAULT false NOT NULL,
    has_terrace boolean DEFAULT false NOT NULL,
    is_furnished boolean DEFAULT false NOT NULL,
    short_description text,
    description text,
    commission numeric(5,2),
    agency_id text NOT NULL,
    owner_id text,
    is_available boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    deleted_at timestamp(3) without time zone
);


ALTER TABLE public.properties OWNER TO aqar_user;

--
-- Name: property_images; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.property_images (
    id text NOT NULL,
    url text NOT NULL,
    is_main boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    property_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.property_images OWNER TO aqar_user;

--
-- Name: rental_managements; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.rental_managements (
    id text NOT NULL,
    reference text NOT NULL,
    rental_id text NOT NULL,
    month integer NOT NULL,
    year integer NOT NULL,
    rent_amount numeric(15,2) NOT NULL,
    charges numeric(15,2),
    expenses numeric(15,2),
    commission numeric(15,2),
    amount_to_owner numeric(15,2),
    is_paid boolean DEFAULT false NOT NULL,
    payment_date timestamp(3) without time zone,
    receipt_url text,
    notes text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.rental_managements OWNER TO aqar_user;

--
-- Name: rentals; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.rentals (
    id text NOT NULL,
    property_id text NOT NULL,
    client_id text NOT NULL,
    owner_id text,
    start_date timestamp(3) without time zone NOT NULL,
    end_date timestamp(3) without time zone,
    monthly_rent numeric(15,2) NOT NULL,
    deposit numeric(15,2),
    agency_fees numeric(15,2),
    status public."RentalStatus" DEFAULT 'active'::public."RentalStatus" NOT NULL,
    documents text[],
    agency_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.rentals OWNER TO aqar_user;

--
-- Name: sales; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.sales (
    id text NOT NULL,
    property_id text NOT NULL,
    client_id text NOT NULL,
    owner_id text,
    final_price numeric(15,2) NOT NULL,
    commission numeric(15,2),
    sale_date timestamp(3) without time zone NOT NULL,
    status public."SaleStatus" DEFAULT 'negociation'::public."SaleStatus" NOT NULL,
    documents text[],
    agency_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.sales OWNER TO aqar_user;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    session_token text NOT NULL,
    user_id text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO aqar_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text,
    email text NOT NULL,
    email_verified timestamp(3) without time zone,
    image text,
    password text,
    role public."UserRole" DEFAULT 'agent'::public."UserRole" NOT NULL,
    agency_id text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO aqar_user;

--
-- Name: verificationtokens; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.verificationtokens (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.verificationtokens OWNER TO aqar_user;

--
-- Name: visits; Type: TABLE; Schema: public; Owner: aqar_user
--

CREATE TABLE public.visits (
    id text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    "time" text NOT NULL,
    client_id text NOT NULL,
    property_id text NOT NULL,
    agent_id text,
    status public."VisitStatus" DEFAULT 'prevue'::public."VisitStatus" NOT NULL,
    result text,
    notes text,
    interest_level public."InterestLevel",
    rating integer,
    price_feedback text,
    follow_up_date timestamp(3) without time zone,
    reminder_sent boolean DEFAULT false NOT NULL,
    agency_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.visits OWNER TO aqar_user;

--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.accounts (id, user_id, type, provider, provider_account_id, refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM stdin;
\.


--
-- Data for Name: agencies; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.agencies (id, name, email, phone, address, wilaya, commune, logo, status, plan, requested_plan, subscription_ends_at, slug, description, showcase_enabled, primary_color, created_at, updated_at) FROM stdin;
cmvz7cb8m000110fbefh1f4zj	Agence Démo	demo@aqar.dz	+213 555 123 456	123 Rue Didouche Mourad	Alger	Alger Centre	\N	active	pro	\N	\N	agence-demo	Agence immobilière implantée à Alger depuis 2010, spécialisée dans la vente et la location de biens résidentiels et commerciaux sur le Grand Alger.	t	#0f172a	2026-11-02 11:55:10.438	2026-11-02 11:55:10.438
cmvz7cb90000210fb7j25vc44	Agence en attente	attente@aqar.dz	+213 555 987 654	\N	Oran	Oran Centre	\N	pending	starter	\N	\N	agence-en-attente	\N	t	#0f172a	2026-11-02 11:55:10.452	2026-11-02 11:55:10.452
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.audit_logs (id, agency_id, user_id, user_name, action, entity, entity_id, summary, created_at) FROM stdin;
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.clients (id, first_name, last_name, phone, email, budget, property_type, wilaya, category, type, status, notes, agency_id, created_at, updated_at, deleted_at) FROM stdin;
cmvz7cbgt001c10fbu65ocx1v	Yacine	Meziane	+213 555 456 789	y.meziane@example.dz	90000000.00	villa	Alger	residentiel	investisseur	visite_prevue	Investisseur, interesse par la villa de Hydra. Paiement comptant possible.	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:10.733	2026-11-02 11:55:10.733	\N
cmvz7cbgt001d10fb9nz9nq7w	Sofiane	Haddad	+213 661 234 567	s.haddad@example.dz	20000000.00	appartement	Alger	residentiel	acheteur	client_chaud	Cherche un F3 sur Alger Centre. Financement bancaire en cours de validation.	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:10.733	2026-11-02 11:55:10.733	\N
cmvz7cbgt001e10fb9v919z6a	Amina	Belkacem	+213 770 345 678	a.belkacem@example.dz	40000.00	studio	Alger	residentiel	locataire	conclu	Etudiante en medecine. Bail signe pour le studio de Bab Ezzouar.	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:10.733	2026-11-02 11:55:10.733	\N
cmvz7cbix001g10fby2psaox5	Riad	Tounsi	+213 770 678 901	\N	35000000.00	\N	Alger	\N	acheteur	nouveau	Premier contact recu via la vitrine en ligne.	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:10.733	2026-11-02 11:55:10.733	\N
cmvz7cbly001i10fbyhrhuvny	Nadia	Ouali	+213 661 567 890	n.ouali@example.dz	130000.00	local_commercial	Alger	commercial	locataire	interesse	Souhaite ouvrir une parapharmacie. Cherche un local avec vitrine.	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:10.733	2026-11-02 11:55:10.733	\N
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.documents (id, name, type, url, size, mime_type, agency_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: interactions; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.interactions (id, type, subject, content, date, author_id, client_id, owner_id, agency_id, created_at, updated_at) FROM stdin;
cmvz7cbp1002c10fb622h57y5	appel	Premier contact	Le client recherche un F3 sur Alger Centre, budget maximum 20 M DA.	2026-10-07 23:00:00	cmvz7cb9i000810fb3ssmj22v	cmvz7cbgt001d10fb9nz9nq7w	\N	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:11.03	2026-11-02 11:55:11.03
cmvz7cbp1002d10fbtgjc90m8	visite	Visite de l appartement F3 Didouche Mourad	Tres bon retour. Le client evoque une offre proche du prix demande.	2026-10-20 23:00:00	cmvz7cb9i000810fb3ssmj22v	cmvz7cbgt001d10fb9nz9nq7w	\N	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:11.03	2026-11-02 11:55:11.03
cmvz7cbp1002e10fb9dgjtxwp	relance	Relance apres visite	Le client confirme son interet, attend l accord de sa banque.	2026-10-24 23:00:00	cmvz7cb9i000810fb3ssmj22v	cmvz7cbgt001d10fb9nz9nq7w	\N	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:11.03	2026-11-02 11:55:11.03
cmvz7cbp1002f10fbbcxn59qa	rendez_vous	Signature du compromis	Compromis signe en agence. Avance de 1 000 000 DA versee.	2026-10-12 23:00:00	cmvz7cb9e000610fbshjx5aej	cmvz7cbgt001d10fb9nz9nq7w	\N	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:11.03	2026-11-02 11:55:11.03
cmvz7cbp1002g10fbtk6p90dl	email	Envoi du dossier de location	Contrat de bail et etat des lieux transmis par courriel.	2026-07-06 23:00:00	cmvz7cb9i000810fb3ssmj22v	cmvz7cbgt001e10fb9v919z6a	\N	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:11.03	2026-11-02 11:55:11.03
cmvz7cbp1002h10fb1pkweuhj	appel	Point mensuel gestion locative	Le proprietaire est informe de la reparation du chauffe-eau.	2026-09-07 23:00:00	cmvz7cb9e000610fbshjx5aej	\N	cmvz7cbdv000c10fbjuidp2ig	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:11.03	2026-11-02 11:55:11.03
cmvz7cbp1002i10fblgu1s4vb	note	Mandat de vente a renouveler	Le mandat exclusif arrive a echeance dans deux mois.	2026-10-22 23:00:00	cmvz7cb9e000610fbshjx5aej	\N	cmvz7cbeb000e10fbjd8r2nje	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:11.03	2026-11-02 11:55:11.03
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.leads (id, first_name, last_name, phone, email, message, status, property_id, agency_id, created_at, updated_at) FROM stdin;
cmvz7cbpe002j10fb3g18z3fc	Karima	Slimani	+213 661 999 888	k.slimani@example.dz	Bonjour, je suis interessee par la villa de Hydra. Serait-il possible d organiser une visite ce week-end ? Merci.	nouveau	cmvz7cbfe000h10fbzo9jbp2u	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:11.043	2026-11-02 11:55:11.043
cmvz7cbpe002k10fbh21mh1hm	Omar	Ferhat	+213 770 111 222	\N	Je cherche un local commercial d environ 100 m2 sur Kouba ou Bir Mourad Rais. Avez-vous d autres biens disponibles ?	nouveau	\N	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:11.043	2026-11-02 11:55:11.043
cmvz7cbpe002l10fby62aiie9	Riad	Tounsi	+213 770 678 901	\N	Bonjour, le duplex de Ain Benian est-il toujours disponible ?	traite	cmvz7cbfz000n10fbcmpo4d0x	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:11.043	2026-11-02 11:55:11.043
\.


--
-- Data for Name: owners; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.owners (id, first_name, last_name, phone, email, address, id_card_number, notes, agency_id, created_at, updated_at, deleted_at) FROM stdin;
cmvz7cbbr000a10fb5g95ajnp	Mohamed	Cherif	+213 661 112 233	m.cherif@example.dz	15 Rue Larbi Ben Mhidi, Alger Centre	160123456789	Proprietaire de plusieurs biens sur Alger Centre. Prefere les contacts par telephone.	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:10.552	2026-11-02 11:55:10.552	\N
cmvz7cbdv000c10fbjuidp2ig	Fatima	Boumediene	+213 770 445 566	f.boumediene@example.dz	8 Boulevard Zighoud Youcef, Alger	160987654321	Confie la gestion locative complete a l agence.	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:10.552	2026-11-02 11:55:10.552	\N
cmvz7cbeb000e10fbjd8r2nje	Ahmed	Zerrouki	+213 555 778 899	a.zerrouki@example.dz	Cite des Anassers, Kouba	\N	Souhaite vendre rapidement.	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:10.552	2026-11-02 11:55:10.552	\N
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.password_reset_tokens (id, token_hash, user_id, expires_at, used_at, created_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.payments (id, reference, amount, type, date, method, status, receipt, notes, property_id, client_id, owner_id, rental_id, sale_id, agency_id, created_at, updated_at) FROM stdin;
cmvz7cbof002010fbaied0xwr	cmvz7cbof002110fb3wg6jujv	70000.00	caution	2026-07-04 23:00:00	cash	paye	\N	Depot de garantie equivalent a deux mois de loyer.	cmvz7cbfl000j10fbd1lo78tg	cmvz7cbgt001e10fb9v919z6a	\N	cmvz7cbno001r10fb3gm3l2ek	\N	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:11.007	2026-11-02 11:55:11.007
cmvz7cbof002210fbiwwrgr3x	cmvz7cbof002310fb5wkwyyup	35000.00	frais_dossier	2026-07-04 23:00:00	cash	paye	\N	Frais d agence a la signature du bail.	cmvz7cbfl000j10fbd1lo78tg	cmvz7cbgt001e10fb9v919z6a	\N	cmvz7cbno001r10fb3gm3l2ek	\N	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:11.007	2026-11-02 11:55:11.007
cmvz7cbof002410fbf2kivekx	cmvz7cbof002510fb5kxamrjg	2800.00	commission_agence	2026-10-02 23:00:00	virement	paye	\N	Commission de gestion du mois.	cmvz7cbfl000j10fbd1lo78tg	\N	\N	cmvz7cbno001r10fb3gm3l2ek	\N	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:11.007	2026-11-02 11:55:11.007
cmvz7cbof002610fbmdrnamyq	cmvz7cbof002710fb0nb1edfy	32200.00	paiement_proprietaire	2026-10-04 23:00:00	virement	paye	\N	Reversement du loyer net au proprietaire.	cmvz7cbfl000j10fbd1lo78tg	\N	cmvz7cbdv000c10fbjuidp2ig	cmvz7cbno001r10fb3gm3l2ek	\N	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:11.007	2026-11-02 11:55:11.007
cmvz7cbof002810fbuj9764pq	cmvz7cbof002910fbe9yjqalh	1000000.00	avance	2026-10-12 23:00:00	ccp	paye	\N	Avance versee a la signature du compromis.	cmvz7cbfz000n10fbcmpo4d0x	cmvz7cbgt001d10fb9nz9nq7w	\N	\N	cmvz7cbn8001p10fbpydp8gge	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:11.007	2026-11-02 11:55:11.007
cmvz7cbof002a10fb9fgykxeg	cmvz7cbof002b10fbwt2k9dvz	775000.00	commission_agence	2026-10-12 23:00:00	virement	partiel	\N	Commission sur la vente, solde a percevoir a l acte authentique.	cmvz7cbfz000n10fbcmpo4d0x	cmvz7cbgt001d10fb9nz9nq7w	\N	\N	cmvz7cbn8001p10fbpydp8gge	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:11.007	2026-11-02 11:55:11.007
\.


--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.properties (id, reference, title, category, type, status, operation_type, sale_price, rent_price, currency, wilaya, commune, quartier, address, surface, rooms, bedrooms, bathrooms, floor, total_floors, has_garage, has_garden, has_terrace, is_furnished, short_description, description, commission, agency_id, owner_id, is_available, created_at, updated_at, deleted_at) FROM stdin;
cmvz7cbel000f10fbv2qm8zsc	cmvz7cbel000g10fb4b66dtus	Appartement F3 lumineux — Alger Centre	residentiel	appartement	disponible	vente	18500000.00	\N	DZD	Alger	Alger Centre	Didouche Mourad	42 Rue Didouche Mourad	95	3	2	1	3	6	f	f	t	f	F3 traversant au cœur d'Alger, proche de toutes commodités.	Bel appartement F3 de 95 m2 situe au 3e etage d un immeuble de standing en plein centre d Alger. Sejour double lumineux donnant sur une terrasse, deux chambres spacieuses, cuisine equipee et salle de bain renovee. Immeuble avec ascenseur, proche des transports, commerces et ecoles.	2.50	cmvz7cb8m000110fbefh1f4zj	cmvz7cbbr000a10fb5g95ajnp	t	2026-11-02 11:55:10.653	2026-11-02 11:55:10.653	\N
cmvz7cbfe000h10fbzo9jbp2u	cmvz7cbfe000i10fbr25le5ns	Villa avec jardin — Hydra	residentiel	villa	disponible	vente	85000000.00	\N	DZD	Alger	Hydra	Val d Hydra	12 Chemin Cheikh Bachir El Ibrahimi	320	7	4	3	\N	2	t	t	t	f	Villa de standing sur 320 m² avec jardin arboré et garage double.	Magnifique villa sur deux niveaux dans le quartier prise d Hydra. Vaste sejour avec cheminee, cuisine americaine equipee, quatre chambres dont une suite parentale, trois salles de bain. Jardin arbore de 200 m2, garage double, systeme de securite. Environnement calme et residentiel.	2.00	cmvz7cb8m000110fbefh1f4zj	cmvz7cbdv000c10fbjuidp2ig	t	2026-11-02 11:55:10.682	2026-11-02 11:55:10.682	\N
cmvz7cbfl000j10fbd1lo78tg	cmvz7cbfl000k10fb4mgbl06x	Studio meublé — Bab Ezzouar	residentiel	studio	loue	gestion_locative	\N	35000.00	DZD	Alger	Bab Ezzouar	Cite AADL	Bat C4, Cite AADL	38	1	1	1	2	\N	f	f	f	t	Studio meublé idéal étudiant, proche de l'université USTHB.	Studio entierement meuble et equipe de 38 m2, situe a proximite immediate de l universite USTHB et de la station de metro. Ideal pour un etudiant ou un jeune actif. Charges de copropriete incluses.	8.00	cmvz7cb8m000110fbefh1f4zj	cmvz7cbdv000c10fbjuidp2ig	t	2026-11-02 11:55:10.689	2026-11-02 11:55:10.689	\N
cmvz7cbfs000l10fb24lqx3jm	cmvz7cbfs000m10fbsdv2n81s	Local commercial 120 m² — Kouba	commercial	local_commercial	disponible	location	\N	120000.00	DZD	Alger	Kouba	\N	5 Rue des Freres Bouadou	120	\N	\N	\N	0	\N	f	f	f	f	Local commercial en rez-de-chaussée sur axe passant.	Local commercial de 120 m2 en rez-de-chaussee avec vitrine sur rue passante. Deux acces, reserve, sanitaires. Convient pour commerce de detail, agence ou showroom. Bail commercial 3-6-9.	10.00	cmvz7cb8m000110fbefh1f4zj	cmvz7cbeb000e10fbjd8r2nje	t	2026-11-02 11:55:10.696	2026-11-02 11:55:10.696	\N
cmvz7cbfz000n10fbcmpo4d0x	cmvz7cbfz000o10fbi66nx7v5	Duplex F5 avec terrasse — Aïn Benian	residentiel	duplex	reserve	vente	32000000.00	\N	DZD	Alger	Ain Benian	\N	\N	165	5	3	2	4	5	t	f	t	f	Duplex F5 avec grande terrasse et vue mer.	Duplex de 165 m2 aux deux derniers etages, offrant une vue degagee sur la mer depuis sa terrasse de 40 m2. Trois chambres, deux salles de bain, double sejour. Place de parking en sous-sol.	2.50	cmvz7cb8m000110fbefh1f4zj	cmvz7cbbr000a10fb5g95ajnp	t	2026-11-02 11:55:10.704	2026-11-02 11:55:10.704	\N
cmvz7cbg6000p10fbzu07bpa4	cmvz7cbg6000q10fbx2mi8mmr	Bureau 60 m² — Chéraga	professionnel	bureau	disponible	location	\N	90000.00	DZD	Alger	Cheraga	\N	\N	60	3	\N	\N	5	\N	f	f	f	f	Bureau équipé dans un immeuble professionnel récent.	Plateau de bureaux de 60 m2 au 5e etage d un immeuble professionnel recent a Cheraga. Climatisation, fibre optique, parking visiteurs, gardiennage 24h/24. Trois espaces de travail cloisonnes.	10.00	cmvz7cb8m000110fbefh1f4zj	cmvz7cbeb000e10fbjd8r2nje	t	2026-11-02 11:55:10.71	2026-11-02 11:55:10.71	\N
\.


--
-- Data for Name: property_images; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.property_images (id, url, is_main, sort_order, property_id, created_at) FROM stdin;
cmvz7cbgf000r10fb8y9x71vh	/images/casbah-interieur.jpg	t	0	cmvz7cbel000f10fbv2qm8zsc	2026-11-02 11:55:10.719
cmvz7cbgf000s10fbmkdpuv07	/images/villa.jpg	f	1	cmvz7cbel000f10fbv2qm8zsc	2026-11-02 11:55:10.719
cmvz7cbgf000t10fbode1ehym	/images/interior.jpg	f	2	cmvz7cbel000f10fbv2qm8zsc	2026-11-02 11:55:10.719
cmvz7cbgf000u10fblygbvh1x	/images/villa.jpg	t	0	cmvz7cbfe000h10fbzo9jbp2u	2026-11-02 11:55:10.719
cmvz7cbgf000v10fbr0bv4wlv	/images/interior.jpg	f	1	cmvz7cbfe000h10fbzo9jbp2u	2026-11-02 11:55:10.719
cmvz7cbgf000w10fbz2lfbvdo	/images/casbah-interieur.jpg	f	2	cmvz7cbfe000h10fbzo9jbp2u	2026-11-02 11:55:10.719
cmvz7cbgf000x10fbptq674pd	/images/interior.jpg	t	0	cmvz7cbfl000j10fbd1lo78tg	2026-11-02 11:55:10.719
cmvz7cbgf000y10fb75guncdz	/images/casbah-interieur.jpg	f	1	cmvz7cbfl000j10fbd1lo78tg	2026-11-02 11:55:10.719
cmvz7cbgf000z10fbz5nqn3js	/images/villa.jpg	f	2	cmvz7cbfl000j10fbd1lo78tg	2026-11-02 11:55:10.719
cmvz7cbgf001010fbesbzqilo	/images/casbah-interieur.jpg	t	0	cmvz7cbfs000l10fb24lqx3jm	2026-11-02 11:55:10.719
cmvz7cbgf001110fbrzhvzld8	/images/villa.jpg	f	1	cmvz7cbfs000l10fb24lqx3jm	2026-11-02 11:55:10.719
cmvz7cbgf001210fbjd6nyslt	/images/interior.jpg	f	2	cmvz7cbfs000l10fb24lqx3jm	2026-11-02 11:55:10.719
cmvz7cbgf001310fb5v5ugnuh	/images/villa.jpg	t	0	cmvz7cbfz000n10fbcmpo4d0x	2026-11-02 11:55:10.719
cmvz7cbgf001410fbafndosb3	/images/interior.jpg	f	1	cmvz7cbfz000n10fbcmpo4d0x	2026-11-02 11:55:10.719
cmvz7cbgf001510fbb005w7gn	/images/casbah-interieur.jpg	f	2	cmvz7cbfz000n10fbcmpo4d0x	2026-11-02 11:55:10.719
cmvz7cbgf001610fbkzitzflp	/images/interior.jpg	t	0	cmvz7cbg6000p10fbzu07bpa4	2026-11-02 11:55:10.719
cmvz7cbgf001710fbdjbpg5ac	/images/casbah-interieur.jpg	f	1	cmvz7cbg6000p10fbzu07bpa4	2026-11-02 11:55:10.719
cmvz7cbgg001810fbfs23m1nw	/images/villa.jpg	f	2	cmvz7cbg6000p10fbzu07bpa4	2026-11-02 11:55:10.719
\.


--
-- Data for Name: rental_managements; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.rental_managements (id, reference, rental_id, month, year, rent_amount, charges, expenses, commission, amount_to_owner, is_paid, payment_date, receipt_url, notes, created_at, updated_at) FROM stdin;
cmvz7cbo3001s10fb44dv874z	cmvz7cbo3001t10fb6dhlnxby	cmvz7cbno001r10fb3gm3l2ek	8	2026	35000.00	2000.00	\N	2800.00	34200.00	t	2026-08-04 23:00:00	\N	\N	2026-11-02 11:55:10.995	2026-11-02 11:55:10.995
cmvz7cbo3001u10fb96u7u4e9	cmvz7cbo3001v10fb2hbr84ij	cmvz7cbno001r10fb3gm3l2ek	9	2026	35000.00	2000.00	8500.00	2800.00	25700.00	t	2026-09-04 23:00:00	\N	Reparation du chauffe-eau avancee par l agence.	2026-11-02 11:55:10.995	2026-11-02 11:55:10.995
cmvz7cbo3001w10fbit6opgmc	cmvz7cbo3001x10fbu359x5az	cmvz7cbno001r10fb3gm3l2ek	10	2026	35000.00	2000.00	\N	2800.00	34200.00	t	2026-10-04 23:00:00	\N	\N	2026-11-02 11:55:10.995	2026-11-02 11:55:10.995
cmvz7cbo3001y10fbeigzdv0h	cmvz7cbo3001z10fbum8mef0h	cmvz7cbno001r10fb3gm3l2ek	11	2026	35000.00	\N	\N	2800.00	32200.00	f	\N	\N	\N	2026-11-02 11:55:10.995	2026-11-02 11:55:10.995
\.


--
-- Data for Name: rentals; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.rentals (id, property_id, client_id, owner_id, start_date, end_date, monthly_rent, deposit, agency_fees, status, documents, agency_id, created_at, updated_at) FROM stdin;
cmvz7cbno001r10fb3gm3l2ek	cmvz7cbfl000j10fbd1lo78tg	cmvz7cbgt001e10fb9v919z6a	cmvz7cbdv000c10fbjuidp2ig	2026-07-04 23:00:00	2027-07-04 23:00:00	35000.00	70000.00	35000.00	active	\N	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:10.98	2026-11-02 11:55:10.98
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.sales (id, property_id, client_id, owner_id, final_price, commission, sale_date, status, documents, agency_id, created_at, updated_at) FROM stdin;
cmvz7cbn8001p10fbpydp8gge	cmvz7cbfz000n10fbcmpo4d0x	cmvz7cbgt001d10fb9nz9nq7w	cmvz7cbbr000a10fb5g95ajnp	31000000.00	775000.00	2026-10-12 23:00:00	compromis	\N	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:10.964	2026-11-02 11:55:10.964
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.sessions (id, session_token, user_id, expires) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.users (id, name, email, email_verified, image, password, role, agency_id, is_active, created_at, updated_at) FROM stdin;
cmvz7cb78000010fbmshwjdlc	Super Admin	superadmin@aqar.dz	\N	\N	$2b$12$HZQ7nL6UjYmosGFKbsna0uc1hgWGlur8aOpQxkiEi5CM77v72/Wy6	super_admin	\N	t	2026-11-02 11:55:10.385	2026-11-02 11:55:10.385
cmvz7cb97000410fbevcmecoo	Admin En Attente	attente@aqar.dz	\N	\N	$2b$12$HZQ7nL6UjYmosGFKbsna0uc1hgWGlur8aOpQxkiEi5CM77v72/Wy6	agency_admin	cmvz7cb90000210fb7j25vc44	t	2026-11-02 11:55:10.459	2026-11-02 11:55:10.459
cmvz7cb9e000610fbshjx5aej	Admin Agence	admin@aqar.dz	\N	\N	$2b$12$HZQ7nL6UjYmosGFKbsna0uc1hgWGlur8aOpQxkiEi5CM77v72/Wy6	agency_admin	cmvz7cb8m000110fbefh1f4zj	t	2026-11-02 11:55:10.466	2026-11-02 11:55:10.466
cmvz7cb9i000810fb3ssmj22v	Karim Benali	agent@aqar.dz	\N	\N	$2b$12$HZQ7nL6UjYmosGFKbsna0uc1hgWGlur8aOpQxkiEi5CM77v72/Wy6	agent	cmvz7cb8m000110fbefh1f4zj	t	2026-11-02 11:55:10.47	2026-11-02 11:55:10.47
\.


--
-- Data for Name: verificationtokens; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.verificationtokens (identifier, token, expires) FROM stdin;
\.


--
-- Data for Name: visits; Type: TABLE DATA; Schema: public; Owner: aqar_user
--

COPY public.visits (id, date, "time", client_id, property_id, agent_id, status, result, notes, interest_level, rating, price_feedback, follow_up_date, reminder_sent, agency_id, created_at, updated_at) FROM stdin;
cmvz7cbmg001j10fb8qy3j7ib	2026-10-20 23:00:00	10:00	cmvz7cbgt001d10fb9nz9nq7w	cmvz7cbel000f10fbv2qm8zsc	cmvz7cb9i000810fb3ssmj22v	effectuee	Le client a beaucoup apprecie la luminosite et la terrasse. Souhaite faire une offre.	\N	tres_interesse	5	Prix juge coherent avec le marche du quartier.	2026-11-03 23:00:00	f	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:10.936	2026-11-02 11:55:10.936
cmvz7cbmg001k10fbz0g73k7y	2026-10-26 23:00:00	14:30	cmvz7cbgt001c10fbu65ocx1v	cmvz7cbfe000h10fbzo9jbp2u	cmvz7cb9i000810fb3ssmj22v	effectuee	Visite positive. Le client demande un second passage avec son epouse.	\N	interesse	4	Trouve le prix un peu eleve, evoque une negociation a 80 M.	2026-11-02 23:00:00	f	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:10.936	2026-11-02 11:55:10.936
cmvz7cbmg001l10fbtnhfu80l	2026-10-29 23:00:00	11:00	cmvz7cbly001i10fbyhrhuvny	cmvz7cbfs000l10fb24lqx3jm	\N	effectuee	La cliente trouve la reserve trop petite pour son activite.	\N	mitige	2	Loyer juge trop eleve pour la surface utile.	\N	f	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:10.936	2026-11-02 11:55:10.936
cmvz7cbmg001m10fb7ykd1o67	2026-11-02 23:00:00	09:30	cmvz7cbgt001c10fbu65ocx1v	cmvz7cbfe000h10fbzo9jbp2u	cmvz7cb9i000810fb3ssmj22v	prevue	\N	Second passage avec l epouse du client.	\N	\N	\N	\N	f	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:10.936	2026-11-02 11:55:10.936
cmvz7cbmg001n10fb1rmpwbnf	2026-11-04 23:00:00	16:00	cmvz7cbix001g10fby2psaox5	cmvz7cbfz000n10fbcmpo4d0x	cmvz7cb9i000810fb3ssmj22v	prevue	\N	Premiere visite. Client venu par la vitrine en ligne.	\N	\N	\N	\N	f	cmvz7cb8m000110fbefh1f4zj	2026-11-02 11:55:10.936	2026-11-02 11:55:10.936
\.


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: agencies agencies_pkey; Type: CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.agencies
    ADD CONSTRAINT agencies_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: interactions interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.interactions
    ADD CONSTRAINT interactions_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: owners owners_pkey; Type: CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.owners
    ADD CONSTRAINT owners_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: property_images property_images_pkey; Type: CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.property_images
    ADD CONSTRAINT property_images_pkey PRIMARY KEY (id);


--
-- Name: rental_managements rental_managements_pkey; Type: CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.rental_managements
    ADD CONSTRAINT rental_managements_pkey PRIMARY KEY (id);


--
-- Name: rentals rentals_pkey; Type: CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.rentals
    ADD CONSTRAINT rentals_pkey PRIMARY KEY (id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: visits visits_pkey; Type: CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_pkey PRIMARY KEY (id);


--
-- Name: accounts_provider_provider_account_id_key; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE UNIQUE INDEX accounts_provider_provider_account_id_key ON public.accounts USING btree (provider, provider_account_id);


--
-- Name: agencies_email_key; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE UNIQUE INDEX agencies_email_key ON public.agencies USING btree (email);


--
-- Name: agencies_slug_key; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE UNIQUE INDEX agencies_slug_key ON public.agencies USING btree (slug);


--
-- Name: audit_logs_agency_id_created_at_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX audit_logs_agency_id_created_at_idx ON public.audit_logs USING btree (agency_id, created_at);


--
-- Name: audit_logs_entity_entity_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX audit_logs_entity_entity_id_idx ON public.audit_logs USING btree (entity, entity_id);


--
-- Name: clients_agency_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX clients_agency_id_idx ON public.clients USING btree (agency_id);


--
-- Name: clients_deleted_at_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX clients_deleted_at_idx ON public.clients USING btree (deleted_at);


--
-- Name: clients_status_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX clients_status_idx ON public.clients USING btree (status);


--
-- Name: documents_agency_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX documents_agency_id_idx ON public.documents USING btree (agency_id);


--
-- Name: documents_type_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX documents_type_idx ON public.documents USING btree (type);


--
-- Name: interactions_agency_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX interactions_agency_id_idx ON public.interactions USING btree (agency_id);


--
-- Name: interactions_client_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX interactions_client_id_idx ON public.interactions USING btree (client_id);


--
-- Name: interactions_owner_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX interactions_owner_id_idx ON public.interactions USING btree (owner_id);


--
-- Name: leads_agency_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX leads_agency_id_idx ON public.leads USING btree (agency_id);


--
-- Name: leads_status_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX leads_status_idx ON public.leads USING btree (status);


--
-- Name: owners_agency_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX owners_agency_id_idx ON public.owners USING btree (agency_id);


--
-- Name: owners_deleted_at_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX owners_deleted_at_idx ON public.owners USING btree (deleted_at);


--
-- Name: password_reset_tokens_expires_at_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX password_reset_tokens_expires_at_idx ON public.password_reset_tokens USING btree (expires_at);


--
-- Name: password_reset_tokens_token_hash_key; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE UNIQUE INDEX password_reset_tokens_token_hash_key ON public.password_reset_tokens USING btree (token_hash);


--
-- Name: password_reset_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX password_reset_tokens_user_id_idx ON public.password_reset_tokens USING btree (user_id);


--
-- Name: payments_agency_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX payments_agency_id_idx ON public.payments USING btree (agency_id);


--
-- Name: payments_property_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX payments_property_id_idx ON public.payments USING btree (property_id);


--
-- Name: payments_reference_key; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE UNIQUE INDEX payments_reference_key ON public.payments USING btree (reference);


--
-- Name: payments_rental_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX payments_rental_id_idx ON public.payments USING btree (rental_id);


--
-- Name: payments_status_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX payments_status_idx ON public.payments USING btree (status);


--
-- Name: payments_type_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX payments_type_idx ON public.payments USING btree (type);


--
-- Name: properties_agency_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX properties_agency_id_idx ON public.properties USING btree (agency_id);


--
-- Name: properties_deleted_at_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX properties_deleted_at_idx ON public.properties USING btree (deleted_at);


--
-- Name: properties_operation_type_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX properties_operation_type_idx ON public.properties USING btree (operation_type);


--
-- Name: properties_reference_key; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE UNIQUE INDEX properties_reference_key ON public.properties USING btree (reference);


--
-- Name: properties_status_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX properties_status_idx ON public.properties USING btree (status);


--
-- Name: properties_type_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX properties_type_idx ON public.properties USING btree (type);


--
-- Name: properties_wilaya_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX properties_wilaya_idx ON public.properties USING btree (wilaya);


--
-- Name: property_images_property_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX property_images_property_id_idx ON public.property_images USING btree (property_id);


--
-- Name: rental_managements_reference_key; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE UNIQUE INDEX rental_managements_reference_key ON public.rental_managements USING btree (reference);


--
-- Name: rental_managements_rental_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX rental_managements_rental_id_idx ON public.rental_managements USING btree (rental_id);


--
-- Name: rental_managements_rental_id_month_year_key; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE UNIQUE INDEX rental_managements_rental_id_month_year_key ON public.rental_managements USING btree (rental_id, month, year);


--
-- Name: rentals_agency_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX rentals_agency_id_idx ON public.rentals USING btree (agency_id);


--
-- Name: rentals_client_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX rentals_client_id_idx ON public.rentals USING btree (client_id);


--
-- Name: rentals_property_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX rentals_property_id_idx ON public.rentals USING btree (property_id);


--
-- Name: rentals_status_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX rentals_status_idx ON public.rentals USING btree (status);


--
-- Name: sales_agency_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX sales_agency_id_idx ON public.sales USING btree (agency_id);


--
-- Name: sales_client_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX sales_client_id_idx ON public.sales USING btree (client_id);


--
-- Name: sales_property_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX sales_property_id_idx ON public.sales USING btree (property_id);


--
-- Name: sales_status_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX sales_status_idx ON public.sales USING btree (status);


--
-- Name: sessions_session_token_key; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE UNIQUE INDEX sessions_session_token_key ON public.sessions USING btree (session_token);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: verificationtokens_identifier_token_key; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE UNIQUE INDEX verificationtokens_identifier_token_key ON public.verificationtokens USING btree (identifier, token);


--
-- Name: verificationtokens_token_key; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE UNIQUE INDEX verificationtokens_token_key ON public.verificationtokens USING btree (token);


--
-- Name: visits_agency_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX visits_agency_id_idx ON public.visits USING btree (agency_id);


--
-- Name: visits_client_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX visits_client_id_idx ON public.visits USING btree (client_id);


--
-- Name: visits_property_id_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX visits_property_id_idx ON public.visits USING btree (property_id);


--
-- Name: visits_status_idx; Type: INDEX; Schema: public; Owner: aqar_user
--

CREATE INDEX visits_status_idx ON public.visits USING btree (status);


--
-- Name: accounts accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_agency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_agency_id_fkey FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: clients clients_agency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_agency_id_fkey FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: documents documents_agency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_agency_id_fkey FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: interactions interactions_agency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.interactions
    ADD CONSTRAINT interactions_agency_id_fkey FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: interactions interactions_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.interactions
    ADD CONSTRAINT interactions_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: interactions interactions_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.interactions
    ADD CONSTRAINT interactions_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.owners(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: leads leads_agency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_agency_id_fkey FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: leads leads_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: owners owners_agency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.owners
    ADD CONSTRAINT owners_agency_id_fkey FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payments payments_agency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_agency_id_fkey FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payments payments_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: payments payments_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.owners(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: payments payments_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: payments payments_rental_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_rental_id_fkey FOREIGN KEY (rental_id) REFERENCES public.rentals(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: payments payments_sale_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_sale_id_fkey FOREIGN KEY (sale_id) REFERENCES public.sales(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: properties properties_agency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_agency_id_fkey FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: properties properties_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.owners(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: property_images property_images_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.property_images
    ADD CONSTRAINT property_images_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rental_managements rental_managements_rental_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.rental_managements
    ADD CONSTRAINT rental_managements_rental_id_fkey FOREIGN KEY (rental_id) REFERENCES public.rentals(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rentals rentals_agency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.rentals
    ADD CONSTRAINT rentals_agency_id_fkey FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rentals rentals_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.rentals
    ADD CONSTRAINT rentals_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rentals rentals_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.rentals
    ADD CONSTRAINT rentals_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.owners(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: rentals rentals_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.rentals
    ADD CONSTRAINT rentals_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sales sales_agency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_agency_id_fkey FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sales sales_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sales sales_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.owners(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sales sales_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: users users_agency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_agency_id_fkey FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: visits visits_agency_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_agency_id_fkey FOREIGN KEY (agency_id) REFERENCES public.agencies(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: visits visits_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: visits visits_property_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: aqar_user
--

ALTER TABLE ONLY public.visits
    ADD CONSTRAINT visits_property_id_fkey FOREIGN KEY (property_id) REFERENCES public.properties(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

